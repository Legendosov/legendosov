﻿using System;
using System.Diagnostics;
using System.Net;
using System.Threading;

namespace ConsoleApplication1
{

    class Program
    {
        public static object WebViewName { get; private set; }

        static void Main(string[] args)
        {
            int choice = 0;
            while (choice != 4)
            {
                Console.WriteLine("Выберите опцию:");
                Console.WriteLine("1. Калькулятор мощности");
                Console.WriteLine("2. Автомобили");
                Console.WriteLine("3. Информация о автомобилях"); 
                Console.WriteLine("4. Доска объявление авто(drom.ru)");
                Console.WriteLine("5. Выход");

                choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Введите мощность в лошадиных силах:");
                        double hp = double.Parse(Console.ReadLine());
                        double kw = hp * 0.7355;
                        Console.WriteLine("{0} л.с. = {1} кВт", hp, kw);
                        break;
                    case 2:
                        Console.WriteLine("Список машин:");
                        Console.WriteLine("1. Toyota");
                        Console.WriteLine("2. Honda");
                        Console.WriteLine("3. BMW");
                        int q = 0;
                        while (q!= 4)
                        {                           
                            Console.WriteLine("4. Назад");

                            q = int.Parse(Console.ReadLine());
                        }
                            break;
                    case 3:
                        int c = 0;
                        while (c!= 4)
                        {
                            Console.WriteLine("Какой автомобиль интересуе:");
                            Console.WriteLine("1. Toyota");
                            Console.WriteLine("2. Honda");
                            Console.WriteLine("3. BMW");
                          

                            c = int.Parse(Console.ReadLine());
                            switch (c)
                            {
                                case 1:
                                    System.Diagnostics.Process txt = new System.Diagnostics.Process();
                                    txt.StartInfo.FileName = "notepad.exe";
                                    txt.StartInfo.Arguments = @"e:\info_avto\Toyota.txt";
                                    txt.Start();
                                    break;
                                case 2:
                                    System.Diagnostics.Process txt2 = new System.Diagnostics.Process();
                                    txt2.StartInfo.FileName = "notepad.exe";
                                    txt2.StartInfo.Arguments = @"e:\info_avto\Honda.txt";
                                    txt2.Start();
                                    break;
                                case 3:
                                    System.Diagnostics.Process txt3 = new System.Diagnostics.Process();
                                    txt3.StartInfo.FileName = "notepad.exe";
                                    txt3.StartInfo.Arguments = @"e:\info_avto\BMW.txt";
                                    txt3.Start();
                                    break;                                
                            } 
                        }
                        break;
                    case 4:
                        Process.Start(new ProcessStartInfo("file:///E:/lp/index.html") { UseShellExecute = true });
                        break;
                    case 5:
                        Console.WriteLine("Выход из программы...");
                        break;
                    default:
                        Console.WriteLine("Неверный выбор. Попробуйте еще раз.");
                        break;
                }
            }
        }

       
    }
}